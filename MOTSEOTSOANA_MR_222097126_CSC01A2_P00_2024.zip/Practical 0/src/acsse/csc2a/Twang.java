//This is the prac 0 practice
package acsse.csc2a;


//This is the main class of the project called Twang.
public class Twang 
{
	public static void main(String[] args)
	{
		/* This is the for-loop that is going to generate 
		*  the number from 1 up to 30 with the step
		*  of 1.
		*/
		for(int i = 1; i <= 30; i++)
		{
			/*Now after generating the sequence 
			 * We gonna check if the number is divisible by the number 3,5, or both.
			 * and the give the certain feedback according to the number
			 * I am going to use the if-statement to do so.
			 */
			if(i % 5 == 0 && i % 3 == 0) //In this line I am saying if the number in the generated sequence is divisible by both 3&5
			{
				System.out.println("HARP"); //This is me saying the word HARP must be displayed if the number is divisible by both 5&3
			}
			else if(i % 5 == 0) //Then in this line I am saying if the number in the generated sequence is divisible by 5
			{
				System.out.println("GUITAR"); //This is me saying the word GUITAR must be displayed if the number is divisible by 5
			}
			else if(i % 3 == 0)//Then in this line I am saying if the number in the generated sequence is divisible by 3
			{
				System.out.println("BANJO"); //This is me saying the word BANJO must be displayed if the number is divisible by 3
			}
			else
			{
				System.out.println(i); //This is me saying that if the number is not divisible by 3 and 5 it must be displayed as it is.
			}
		}
	}
}
